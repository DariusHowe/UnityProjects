﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayField : MonoBehaviour
{
    public static int w = 10;
    public static int h = 20;
    //Creates a grid of hieght 20 and width 10
    public static Transform[,] grid = new Transform[w, h];

    //Functions keeps coordinates of rotated minos as whole numbers
    public static Vector2 roundVec2(Vector2 v)
    {
        return new Vector2(Mathf.Round(v.x), Mathf.Round(v.y));
    }

    //Making restrictions to the possible lengths the mino can move to
    public static bool insideBorder(Vector2 pos)
    {
        //Checks if position is within the window
        //Still needs check case for is position is outside of y
        return ((int)pos.x >= 0 && (int)pos.x < w && (int)pos.y >= 0);
    }

    public static void deleteRow(int y)
    {
        //Put a score counter in and display the total number of lines cleared
        //Create a function that changes the speed of falling minos as lines get deleted
        for(int x=0; x < w; ++x)
        {
            //Removes that full row of minos
            Destroy(grid[x, y].gameObject);
            //creates a new empty set now that the full set is deleted
            grid[x, y] = null;
        }
    }

    public static void decreaseRow(int y)
    {
        for (int x = 0; x < w; ++x)
        {
            if (grid[x, y] != null)
            {
                grid[x, y - 1] = grid[x, y];
                grid[x, y] = null;
                //Reassigns new bottom row position
                grid[x, y - 1].position += new Vector3(0, -1, 0);
            }
        }
    }

    public static void decreaseUp(int y)
    {
        for(int i = y; i < h; ++i)
        {
            decreaseRow(i);
        }
    }

    public static bool IsRowFull(int y)
    {
        for(int x = 0; x < w; ++x)
        
            if (grid[x, y] == null)
            
                return false;
            
        return true;
        
    }

    public static void deleteFullRows()
    {
        for(int y = 0; y < h; ++y)
        {
            if (IsRowFull(y))
            {
                deleteRow(y);
                decreaseUp(y + 1);
                --y;
            }
        }
    }
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
