﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawner : MonoBehaviour
{

    public GameObject[] minos;

    public void spawnNext()
    {
        //Random Number between 0 and the length of our minos group declaration
        //Using to have spawner pick a random index within our range in the array
        //Use -1 so that 
        int i = Random.Range(0, minos.Length - 1);

        Instantiate(minos[i],
            //Creates orientation and position of new spawned tetrimino
            transform.position,
            Quaternion.identity);
    }
    // Start is called before the first frame update
    void Start()
    {
        spawnNext();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
